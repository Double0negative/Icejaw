package runtime.functions;

public class Help {

	
	public void start(){
		
	}
}
