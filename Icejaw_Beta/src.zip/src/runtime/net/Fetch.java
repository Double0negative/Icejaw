package runtime.net;

public class Fetch {

}
