package runtime.main;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class startup {
	
	static JFrame net = new JFrame("Waiting for Network");
	JPanel p = new JPanel();
	JLabel l = new JLabel("Wating for Network");
	
	
	
	
    public static void main(String args[]){
    	new startup().setup();
    }
    
    
    
    
    public void setup(){
    	try{
    		net.setSize(200,25);
    		net.setUndecorated(true);
    		net.setLocationRelativeTo(null);
    		
    		net.add(p);
    		p.setBackground(Color.black);
    		
    		p.add(l);
    		l.setForeground(Color.white);
    		net.setVisible(true);
    		
    		
    		
    		
    		
    	new index().main();
    	}
    	catch(Exception e){
    		index.kill("there was a problem with icejaw",e);
    	}
    	
    	}
    
    
    public static void closeStartWindow(){
    	
    	net.dispose();
    	
    }
    
}
