package runtime.net;

public class Site {

	
	String url = "";
	String username = "";
	String pass ="";
	
	public Site(String url, String username, String pass){
		
		this.url = url;
		this.username = username;
		this.pass = pass;
	}
	
	
	
}
