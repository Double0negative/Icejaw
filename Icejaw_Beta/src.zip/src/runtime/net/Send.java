package runtime.net;

public class Send {

}
